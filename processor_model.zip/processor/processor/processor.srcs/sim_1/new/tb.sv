`timescale 1ns / 1ps

module tb();
logic sel;          
logic clk;          
logic en;           
logic rst_n;        
logic [2:0] pc;     
logic [1:0] flags;  
logic [3:0] results; 


top top(
       .sel,
       .clk,
       .en,
       .rst_n,
       .pc,
       .flags,
       .results
    );
initial begin
clk=0;
forever #10 clk=~clk;
end    

initial begin
rst_n=0;
sel=0;
@(posedge clk);
rst_n=1;
repeat(10) @(posedge clk);  
$stop();
end
endmodule
