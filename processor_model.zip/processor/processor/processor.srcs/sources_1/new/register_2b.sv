`timescale 1ns / 1ps



module register_2b(
        input logic [1:0] in,
        input logic       rst_n,
        input logic         clk,
       output logic [1:0] out
    );
    
    always_ff@(posedge clk)
    begin
    if(~rst_n)
    begin
    out = 0;
    end
    else
    begin
    out=in;
    end
    end
endmodule
