`timescale 1ns / 1ps


module alu(
        input logic [2:0] opcode,
        input logic [3:0] op1,
        input logic [3:0] op2,
       output logic       cf,  
       output logic       zf,  
       output logic [3:0] result        
    );
    
    always_comb
    begin
    cf=0;
    zf=0;
    case(opcode)
    3'b000:
    begin
     result= 0; 
    end
    3'b001: result= op1;
    3'b010: result= ~op1;
    3'b011: {cf,result}= op1 + op2;
    3'b100: {cf,result}= op2 - op1;
    3'b101: result= op2&op1;
    3'b110: result= op2|op1;
    3'b111: result= op2^op1;
    endcase
    end
    assign zf= result==0;
endmodule
