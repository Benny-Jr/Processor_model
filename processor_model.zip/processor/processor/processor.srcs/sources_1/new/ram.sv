`timescale 1ns / 1ps


module ram(
        input logic clk,
        input logic [3:0] waddr,
        input logic [3:0] raddr1,
        input logic [3:0] raddr2,
       output logic [3:0] rdata1,
       output logic [3:0] rdata2,
        input logic       we    ,
        input logic [3:0] wdata
    );
    logic [3:0] memorie_efectiva [0:15];
    assign rdata1=memorie_efectiva[raddr1];
    assign rdata2=memorie_efectiva[raddr2];
    always_ff @(posedge clk)
    begin
    if(we) memorie_efectiva[waddr]=wdata;
    end
    
endmodule
