`timescale 1ns / 1ps

module rom(
        input logic [2:0] addr,
       output logic [15:0] out 
    );
    
always_comb
begin
case(addr)
3'b000: out=16'h9005;
3'b001: out=16'h910A;
3'b010: out=16'h5201;
3'b011: out=16'h3301;
3'b100: out=16'h4401;
3'b101: out=16'h1703;
3'b110: out=16'h1804;
3'b111: out=16'h7F78;
endcase
end
endmodule
