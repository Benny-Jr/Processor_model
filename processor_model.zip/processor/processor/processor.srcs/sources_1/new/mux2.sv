`timescale 1ns / 1ps

module mux2(
        input logic in0,
        input logic in1,
       output logic out,
        input logic sel
    );
    
    always_comb
    begin
    if(sel) out=in1;
    else    out=in0;
    end
endmodule
