`timescale 1ns / 1ps


module counter3b(
        input logic clk,
        input logic rst_n,
        input logic en,
       output logic [2:0] out
    );
    always_ff @(posedge clk or negedge rst_n) //de fct asincron
    begin
        if(~rst_n)
        begin
        out = 0;
        end
        else if(en)
        out=out+1;
    end
endmodule
