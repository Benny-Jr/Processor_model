`timescale 1ns / 1ps

module top(
        input logic sel,
        input logic clk,
        input logic en,
        input logic rst_n,
       output logic [2:0] pc,
       output logic [1:0] flags,
       output logic [3:0] results
    );


    logic [31:0] c32_out;
    logic mux2_clk_out;
    logic [2:0]  c3_out;
    logic [15:0] instruction;
    logic sau;
    logic [3:0] result;
    logic [3:0] rdata1;
    logic [3:0] rdata2;
    logic zf;
    logic cf;
    logic [1:0] reg2_in;
    logic [3:0] mux2_bot;
    
    assign reg2_in={cf,zf};
    assign pc=c3_out;
    assign sau= (instruction[15]|instruction[14]|instruction[13]|instruction[12]);
    assign results = result;
   
    
    
counter counter32(
       .clk(clk),
       .rst_n(rst_n),
       .en(en),
       .out(c32_out)
    );
mux2 mux2_top(
       .in0(clk),
       .in1(c32_out[26]),
       .out(mux2_clk_out),
       .sel(sel)
    );
    
counter3b counter3b(
       .clk(mux2_clk_out),
       .rst_n(rst_n),
       .en(1),
       .out(c3_out)
    );

rom rom(
       .addr(c3_out),
       .out(instruction) 
    );        
 
 ram ram(
       .clk(mux2_clk_out),
       .waddr(instruction[11:8]),
       .raddr1(instruction[3:0]),
       .raddr2(instruction[7:4]),
       .rdata1(rdata1),
       .rdata2(rdata2),
       .we    (sau),
       .wdata (result)
    );
    
  always_comb
  begin
  if(instruction[15])
  mux2_bot=instruction[3:0];
  else mux2_bot=rdata1;
  end  
  
  alu alu(
       .opcode(instruction[14:12]),
       .op1(mux2_bot),
       .op2(rdata2),
       .cf(cf),  
       .zf(zf),  
       .result(result)        
    );
    
   register_2b reg_2b(
      .in(reg2_in),
      .rst_n(rst_n),
      .clk(mux2_clk_out),
      .out(flags)
    );          
    
endmodule













